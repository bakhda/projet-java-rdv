/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.ListezRendezvous;
import entities.Rendez_vous;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class ListezRendezvousDao implements IDao<ListezRendezvous>{
        DataBase database= new DataBase();
        
        
        /*Request sql*/
    private final String SQL_INSERT="INSERT INTO `rendez_vous` (`libelle`, `nom`, `prenom`, `consultation_demander`, `prestation_demander`) VALUES (?,?,?,?,?)";
    private final String SQL_UPDATE="UPDATE `rendez_vous` SET `libelle`=?, WHERE `id_rendez_vous`= ?";
    private final String SQL_DELETE="Delete from rendez_vous where id_rendez_vous=?";
    private final String SQL_ALL=" SELECT * FROM rendez_vous";
    private final String SQL_BY_ID="SELECT * FROM `rendez_vous` WHERE id_rendez_vous=?";
     private final String SQL_BY_PROF_ANNEE="SELECT * FROM rendez_vous c, affectation a, user p  WHERE c.id_rendez_vous=a.id_consulation and a.prof_id=p.id_user "
                                                               +" and a.annee like ? and p.nci like ?";

     
     

    @Override
    public int insert(ListezRendezvous lrv) {
int lastInsertId=0;
        database.openConnexion();
        database.initPrepareStatement(SQL_INSERT);
        try {
            database.getPs().setString(1, lrv.getLibelle());
            database.getPs().setString(2, lrv.getNom());
            database.getPs().setString(3, lrv.getPrenom());
            database.getPs().setString(4, lrv.getConsultaion_demander());
            database.getPs().setString(5, lrv.getPrestation_demander());

            database.executeUpdate(SQL_INSERT);
            ResultSet rs=database.getPs().getGeneratedKeys();
            if(rs.next()){
            lastInsertId=rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        database.closeConnexion();
        return lastInsertId;    }

    @Override
    public int update(ListezRendezvous lrv) {
 int nbrLigne=0;
        database.openConnexion();
        database.initPrepareStatement(SQL_UPDATE);
        try {
             database.getPs().setString(1, lrv.getLibelle());
            database.getPs().setString(2, lrv.getNom());
            database.getPs().setString(3, lrv.getPrenom());
            database.getPs().setString(4, lrv.getConsultaion_demander());
            database.getPs().setString(5, lrv.getPrestation_demander());
            nbrLigne=database.executeUpdate(SQL_UPDATE);         
        } catch (SQLException ex) {
            Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        database.closeConnexion();
        return nbrLigne;    }

    @Override
    public int delete(int id) {
 int nbrLigne=0;
        database.openConnexion();
        database.initPrepareStatement(SQL_DELETE);
        try {
            database.getPs().setInt(1, id);
            nbrLigne=database.executeUpdate(SQL_UPDATE);
            
        } catch (SQLException ex) {
            Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        database.closeConnexion();
        return nbrLigne;    }

    @Override
    public List<ListezRendezvous> findAll() {
 List<ListezRendezvous> ListezRendezvous=new ArrayList<>();
        database.openConnexion();
        database.initPrepareStatement(SQL_ALL);
       
            ResultSet rs =database.executeSelect(SQL_ALL);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    ListezRendezvous lrv =new ListezRendezvous(rs.getInt("id_rendez_vous"),rs.getString("libelle"),rs.getString("nom"),rs.getString("prenom"));
                    ListezRendezvous.add(lrv);
                } catch (SQLException ex) {
                    Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        database.closeConnexion();
        return ListezRendezvous;    }

    @Override
    public ListezRendezvous findById(int id) {
        ListezRendezvous listezrendezvous=null;
        database.openConnexion();
        database.initPrepareStatement(SQL_BY_ID);
       
            ResultSet rs =database.executeSelect(SQL_BY_ID);    
            try {
                //Mapping relation vers objet
                ListezRendezvous lrv =new ListezRendezvous(rs.getInt("id_rendez_vous"),rs.getString("libelle"),rs.getString("nom"),rs.getString("prenom"));
                listezrendezvous.add(lrv);

            } catch (SQLException ex) {
                Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        database.closeConnexion();
        return listezrendezvous;
    }
    
     public List<ListezRendezvous> findRendezvousByPatient(String nom,String prenom) {
        List<ListezRendezvous> classes=new ArrayList<>();
        database.openConnexion();
        database.initPrepareStatement(SQL_BY_PROF_ANNEE);
        try {
            database.getPs().setString(1, nom);
            database.getPs().setString(2, prenom);
        } catch (SQLException ex) {
            Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
            ResultSet rs =database.executeSelect(SQL_BY_PROF_ANNEE);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    ListezRendezvous cl =new ListezRendezvous(rs.getInt("id_rendez_vous"),rs.getString("libelle"),rs.getString("nom"),rs.getString("prenom"));
                    classes.add(cl);
                } catch (SQLException ex) {
                    Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        database.closeConnexion();
        return classes;
    }

    public List<ListezRendezvous> findall() {
 List<ListezRendezvous> rendezvous=new ArrayList<>();
        database.openConnexion();
        database.initPrepareStatement(SQL_ALL);
       
            ResultSet rs =database.executeSelect(SQL_ALL);
        
        try {
            while(rs.next()){
                try {
                    //Mapping relation vers objet
                    ListezRendezvous cl =new ListezRendezvous(rs.getInt("id_rendez_vous"),rs.getString("libelle"),rs.getString("nom"),rs.getString("prenom"));
                    rendezvous.add(cl);
                } catch (SQLException ex) {
                    Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(ListezRendezvousDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        database.closeConnexion();
        return rendezvous;    }

    public List<ListezRendezvous> findAll(String libelle, String nom) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<ListezRendezvous> findListezRendezvousByPatient(String libelle, String nom) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
