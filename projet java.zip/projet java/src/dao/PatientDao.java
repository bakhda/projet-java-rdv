/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lenovo
 */
public class PatientDao implements IDao<Patient>{
        //création d'un objet  database dans patient

    private final DataBase database = new DataBase();
     //requete SQL pour un INSERT de patient
    private final String SQL_INSERT="INSERT INTO user"
            + "(`login`,`password`,`nom`,`prenom`,`role`)"
            + "VALUES(?,?,?,?,'ROLE_PATIENT')";
   //requete SQL pour une Update
    private final String SQL_UPDATE="SELECT * FROM patient WHERE ";
    private final String SQL_SELECT_PATIENT_BY_ID = "SELECT * FROM patient p, rendez_vous rv, "
            + "WHERE id = ";
    
   //code d'nsertion par etape bien def
    @Override
    public int insert(Patient pat) {
        int id=0;
        database.openConnexion();
        //chargement de la base de donnee et des requetes
        database.initPrepareStatement(SQL_INSERT);
        try {
            database.getPs().setString(1, pat.getLogin());
            database.getPs().setString(2, pat.getPassword());
            database.getPs().setString(3, pat.getNom());
            database.getPs().setString(4, pat.getPrenom());
            database.executeUpdate(SQL_INSERT);
            ResultSet rs= database.getPs().getGeneratedKeys();
            if(rs.next()){
                id=rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(PatientDao.class.getName()).log(Level.SEVERE, null, ex);
        }return id;
    }
    
   

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Patient> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 
    @Override
    public int update(Patient ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
     @Override
    public Patient findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    }

    
