/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entities.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author Lenovo
 */
public class Rendez_vousDao implements IDao<Rendez_vous>{
    
        //création d'un objet  database dans patient

    private final DataBase database = new DataBase();
     //requete SQL pour un INSERT de patient
    private final String SQL_INSERT="INSERT INTO rendez_vous"
            + "(`libelle`,`nom`,`prenom`,`role`)"
            + "VALUES(?,?,?,?,'ROLE_PATIENT')";
   //requete SQL pour une Update
    private final String SQL_UPDATE="SELECT * FROM rendez_vous WHERE ";
    private final String SQL_SELECT_ID_RENDEZ_VOUS_BY_ID = "SELECT * FROM rendez_vous rv, rendez_vous rv, "
            + "WHERE id = ";
    
   //code d'nsertion par etape bien def
    @Override
    public int insert(Rendez_vous rv) {
        int id=0;
        database.openConnexion();
        //chargement de la base de donnee et des requetes
        database.initPrepareStatement(SQL_INSERT);
        try {
            database.getPs().setString(2, rv.getNom());
            database.getPs().setString(3, rv.getPrenom());
            database.executeUpdate(SQL_INSERT);
            ResultSet rs= database.getPs().getGeneratedKeys();
            if(rs.next()){
                id=rs.getInt(1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(Rendez_vousDao.class.getName()).log(Level.SEVERE, null, ex);
        }return id;
    }
    
   

    @Override
    public int delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Rendez_vous> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 
    @Override
    public int update(Rendez_vous ogj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
     @Override
    public Rendez_vous findById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    }

    

