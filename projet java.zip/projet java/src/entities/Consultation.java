/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author Lenovo
 */
public class Consultation {
    private int id;
    private int temperature;
    private int tension;
    private String prestation_a_faire;
    private Medecin medecin;
    public List<Ordenance> ordenance;
     public Consultation (){  
}   

    public Consultation(int temperature, int tension, String prestation_a_faire) {
        this.temperature = temperature;
        this.tension = tension;
        this.prestation_a_faire = prestation_a_faire;
    }

    public Consultation(int id, int temperature, int tension, String prestation_a_faire) {
        this.id = id;
        this.temperature = temperature;
        this.tension = tension;
        this.prestation_a_faire = prestation_a_faire;
    }

    
     

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getTemperature() {
        return temperature;
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }

    public int getTension() {
        return tension;
    }

    public void setTension(int tension) {
        this.tension = tension;
    }

    public String getPrestation_a_faire() {
        return prestation_a_faire;
    }

    public void setPrestation_a_faire(String prestation_a_faire) {
        this.prestation_a_faire = prestation_a_faire;
    }
     
            
}
