/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.Date;
import java.util.List;

/**
 *
 * @author Lenovo
 */
public class Consultationpatient  {
    
    protected int id;
    protected Date date;
    protected String libelle;
    protected String nom;
    protected String prenom;
    protected  Consultation consultation;
    protected  List<Prestationpatient> prestations;
    protected  String consultation_demander;

    public Consultationpatient() {
    }

    public Consultationpatient(Date date, String libelle, String nom, String prenom, Consultation consultation, List<Prestationpatient> prestations, String consultation_demander) {
        this.date = date;
        this.libelle = libelle;
        this.nom = nom;
        this.prenom = prenom;
        this.consultation = consultation;
        this.prestations = prestations;
        this.consultation_demander = consultation_demander;
    }

    public Consultationpatient(int id, Date date, String libelle, String nom, String prenom, Consultation consultation, List<Prestationpatient> prestations, String consultation_demander) {
        this.id = id;
        this.date = date;
        this.libelle = libelle;
        this.nom = nom;
        this.prenom = prenom;
        this.consultation = consultation;
        this.prestations = prestations;
        this.consultation_demander = consultation_demander;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public Consultation getConsultation() {
        return consultation;
    }

    public void setConsultation(Consultation consultation) {
        this.consultation = consultation;
    }

    public List<Prestationpatient> getPrestations() {
        return prestations;
    }

    public void setPrestations(List<Prestationpatient> prestations) {
        this.prestations = prestations;
    }

    public String getConsultation_demander() {
        return consultation_demander;
    }

    public void setConsultation_demander(String consultation_demander) {
        this.consultation_demander = consultation_demander;
    }

  


    
}