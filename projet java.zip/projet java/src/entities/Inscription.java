/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.time.Year;

/**
 *
 * @author Lenovo
 */
public class Inscription {
    private User user;
    private Patient patient;
    private int id;
    private String annee;
    private String nom;
    private String prenom;
    private int Tel;
    private String Email;

    public Inscription() {
    }

    public Inscription(int id, String annee, String nom, String prenom, int Tel, String Email) {
        this.id = id;
        this.annee = annee;
        this.nom = nom;
        this.prenom = prenom;
        this.Tel = Tel;
        this.Email = Email;
    }

    public Inscription(String annee, String nom, String prenom, int Tel, String Email) {
        this.annee = annee;
        this.nom = nom;
        this.prenom = prenom;
        this.Tel = Tel;
        this.Email = Email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAnnee() {
        return annee;
    }

    public void setAnnee(String annee) {
        this.annee = annee;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getTel() {
        return Tel;
    }

    public void setTel(int Tel) {
        this.Tel = Tel;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
    
    
    
}
