/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author Lenovo
 */
public class Patient extends User {
        private int code;
        private String antecedent_medicaux;
        private DossierMedical dossiermedical;
      
       
            private final String ROLE="ROLE_PATIENT";

public  Patient (){
     //super();
        this.role=ROLE;
}

    public Patient(String antecedent_medicaux, DossierMedical dossiermedical, String nom, String prenom, String login, String password, String role) {
        super(antecedent_medicaux,nom, prenom, login, password, role);
        this.antecedent_medicaux = antecedent_medicaux;
        this.dossiermedical = dossiermedical;
    }

    private Patient(int id, String nom, String prenom, String login, String password, String role) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getAntecedent_medicaux() {
        return antecedent_medicaux;
    }

    public void setAntecedent_medicaux(String antecedent_medicaux) {
        this.antecedent_medicaux = antecedent_medicaux;
    }

    public Patient(int code, String antecedent_medicaux, String nom, String prenom) {
        super(nom, prenom);
        this.code = code;
        this.antecedent_medicaux = antecedent_medicaux;
    }

    public Patient(int code, String antecedent_medicaux, int id, String nom, String prenom, String login, String password, String role) {
        super(id,  antecedent_medicaux, nom, prenom, login, password, role);
        this.code = code;
        this.antecedent_medicaux = antecedent_medicaux;
    }


    

    public Patient(int code, String antecedent_medicaux) {
        this.code = code;
        this.antecedent_medicaux = antecedent_medicaux;
    }

    public String getConsultation_demander() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

  

  

   




}
