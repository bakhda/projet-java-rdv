/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.util.List;

/**
 *
 * @author Lenovo
 */
public class ResponsablePrestation extends User {
    
    public List<Prestationpatient> prestation;
    
    public  ResponsablePrestation (){
        
    }

    public ResponsablePrestation(String nom, String penom, String login, String password, String role, String tel) {
        super(nom, penom, login, password, role, tel);
    }

    public ResponsablePrestation(int id, String nom, String penom, String login, String password, String role, String tel) {
        super(id, nom, penom, login, password, role, tel);
    }
    
    
}
