/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.MedecinDao;
import dao.PatientDao;
import dao.SecretaireDao;
import dao.ConsultationPatientDao;
import dao.PrestationPatientDao;
import dao.ListezRendezvousDao;
import dao.Rendez_vousDao;




import entities.Patient;
import entities.Consultationpatient;
import entities.Rendez_vous;

import entities.User;
import java.util.List;
import javafx.scene.control.ComboBox;
import dao.UserDao;
import entities.ListezRendezvous;
import entities.Prestationpatient;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;



/**
 *
 * @author Lenovo
 */
public class Service implements IService {
    
     //Dependances avec la couche DAO
    /**AffectationDao daoAff=new AffectationDao();**/
    MedecinDao daoMedecin=new MedecinDao();
    PatientDao daoPatient=new PatientDao();
    SecretaireDao daoSecretaire=new SecretaireDao();
    ConsultationPatientDao daoConsultationpatient=new ConsultationPatientDao();
    PrestationPatientDao daoPrestationpatient=new PrestationPatientDao();
    ListezRendezvousDao daoListezRendezvous=new ListezRendezvousDao();

    UserDao daoUser=new UserDao();


    public static void loadComboBoxAnnee(ComboBox<String> cboAnnee) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

 //pour inserer un patient le type de retour
    @Override
    public int addPatient(Patient patient) {
        return daoPatient.insert(patient);
        
    }
   
    @Override
    public int addPrestationpatient(Prestationpatient prestationpatient) {
        return daoPrestationpatient.insert(prestationpatient);
        
    }
    
    
    
      @Override
    public int addConsultationpatient(Consultationpatient consultationpatient) {
        return daoConsultationpatient.insert(consultationpatient);
        
    }
    
    
  
  
   
    @Override
    public boolean updatePatient(Patient patient) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean deletePatient(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Patient> searchAllPatient() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Patient searchOnePatient(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int addRendez_vous(Rendez_vous rendez_vous) {
                throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.

    }

    @Override
    public boolean updateRendez_vous(Rendez_vous Rendez_vous) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean deleteRendez_vous(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<ListezRendezvous>showListezRendezvousByPatient(String libelle, String nom){
    return daoListezRendezvous.findListezRendezvousByPatient(libelle, nom);
    }

    @Override
    public Rendez_vous searchOneRendez_vous(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    @Override
    public List<Patient> searchSecretaireByResponsablePrestation(String nci, String Date) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
    

    @Override
    public User login(String login, String password) {
        return daoUser.findUserLoginAndPassword(login, password);
        
    }

    public int addRendez_vous(ListezRendezvous listezRendezvous) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean updateListezRendezvous(ListezRendezvous classeSelected) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
    @Override
    public List<Rendez_vous> searchAllRendez_vous() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   


    public List<ListezRendezvous> showAllListezRendez_vous() {
        return daoListezRendezvous.findAll();
    }

    @Override
    public List<Rendez_vous> showAllRendez_vous() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    

 
    
    
  
   
   
   
}
