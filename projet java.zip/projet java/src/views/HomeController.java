/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class HomeController implements Initializable {

    @FXML
    private Button btnMedecin;
    @FXML
    private Button btnPatient;
    @FXML
    private Button btnSecretaire;
    @FXML
    private Button btnRP;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handleMedecin(ActionEvent event) {
         AnchorPane root = null;
         this.btnPatient.getScene().getWindow().hide();
    
              try {
                  root = FXMLLoader.load(getClass().getResource("/views/v_connexionMedecin.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
              
              
    }

    @FXML
    private void handlePatient(ActionEvent event) {
            AnchorPane root = null;
            this.btnPatient.getScene().getWindow().hide();

              try {
                  root = FXMLLoader.load(getClass().getResource("/views/v_connexion.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
    }

    @FXML
    private void handleSecretaire(ActionEvent event) {
          AnchorPane root = null;
          this.btnPatient.getScene().getWindow().hide();

              try {
                  root = FXMLLoader.load(getClass().getResource("/views/v_connexionSecretaire.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
        
    }

    @FXML
    private void handleRP(ActionEvent event) {
          AnchorPane root = null;
          this.btnPatient.getScene().getWindow().hide();
              try {
                  root = FXMLLoader.load(getClass().getResource("/views/v_connexionRp.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
        
    }
    
}
