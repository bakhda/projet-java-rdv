/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import entities.Patient;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author HP
 */
public class InscriptionController implements Initializable {

    @FXML
    private TextField txtPass;
    @FXML
    private TextField txtnom;
    @FXML
    private TextField textprenom;
    @FXML
    private TextField txtlogin;
    @FXML
    private final Service service = new Service();
    
    private static InscriptionController ctrl;
    
    private User user;
    private Patient patient;
    @FXML
    private Label txterror;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        txterror.setVisible(false);
    }    

    @FXML
    private void handleclear(ActionEvent event) {
        txtnom.clear();
        textprenom.clear();
        txtlogin.clear();
        txtPass.clear();
        txterror.setVisible(false);

    }

    @FXML
    private void handleconnexion (ActionEvent event) {
        // Recuperation des donnees de chaque champs du patient
        String login = txtlogin.getText().trim();
        String password = txtPass.getText().trim();
        String nom = txtnom.getText().trim();
        String prenom = textprenom.getText().trim();
        //String age = txtfAgeCC.getText().trim();
        //String adresse = txtfAdresseCC.getText().trim();


        //Verification des champs null cad non remplit
        if(login.isEmpty() || password.isEmpty() 
                ||prenom.isEmpty()
                || nom.isEmpty())
        {
          txterror.setText("Tout les Champs sont Obligatoire");
          txterror.setVisible(true);
        }
        else{
            //insertion des éléments
          Patient pat=new Patient();
          pat.setLogin(login);
          pat.setPassword(password);
          pat.setNom(nom);
          pat.setPrenom(prenom);
        service.addPatient(pat);

              //Cache la fénétre de connexion
              this.txterror.getScene().getWindow().hide();
              AnchorPane root = null;
              
              try {
                  //chargement de la view connexion directement
                  
                  root = FXMLLoader.load(getClass().getResource("/views/v_connexion.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
              this.txterror.getScene().getWindow().hide();
          }
        }
}
