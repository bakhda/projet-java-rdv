/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import dao.DataBase;
import java.sql.*;
import dao.IDao;
import entities.Consultationpatient;
import entities.ListezRendezvous;
import entities.Rendez_vous;
import entities.User;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import services.Service;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class ListezRendezvousController implements Initializable{
    
     private User user;
      ObservableList<ListezRendezvous> obvRendezvous;
    private ListezRendezvous listezrendezvousSelected;
    private final Service service = new Service();
    private static ConnexionController ctrl;
      public static ConnexionController getCtrl(){
        return ctrl;
    }
    @FXML
    private TableColumn<ListezRendezvous,String> tbLibelle;
    @FXML
    private TableColumn<ListezRendezvous,String> tbnom;
    @FXML
    private TableColumn<ListezRendezvous,String> tbprenom;
    @FXML
    private TableColumn<ListezRendezvous,String> tbId;
    @FXML
    private TableColumn<ListezRendezvous,String> tbconsultationdemandé;
    @FXML
    private TableColumn<ListezRendezvous,String> tbprestationdemandé;
    
    @FXML
    private TextField txtfLibelle;
    @FXML
    private TableView<ListezRendezvous> tblvClasse;
    
    
    public User getUser(){
        return user;
    }
    

    

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    public void initialize(URL url, ResourceBundle rb) {
        loadTableView();
    }    
    
    private void loadTableView(){
        List<ListezRendezvous> listezrendezvous=service.showAllListezRendez_vous();
        obvRendezvous=FXCollections.observableArrayList(listezrendezvous);
        //Construction des colonnes
        tbId.setCellValueFactory(new PropertyValueFactory<>("id"));
        tbLibelle.setCellValueFactory(new PropertyValueFactory<>("libelle")); 
                tbnom.setCellValueFactory(new PropertyValueFactory<>("nom"));        
        tbprenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));        

        tblvClasse.setItems(obvRendezvous);
    }


    @FXML
    private void handleAddRv(ActionEvent event) {
        if(txtfLibelle.getText().trim().isEmpty()){
            Alert alert =new Alert(Alert.AlertType.ERROR);
            alert.setTitle("classe");
            alert.setContentText("Veuillez saisir le libelle");
            alert.show();
        }else{
            ListezRendezvous listezrendezvous=new ListezRendezvous(txtfLibelle.getText());
            int id=service.addRendez_vous(listezrendezvous);
            listezrendezvous.setId(id);
            Alert alert =new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("classe");
            alert.setContentText("Classe enregistee avec succes");
            alert.show();
                     ObservableList<ListezRendezvous> obvRendez_vous = null;

            obvRendez_vous.add(listezrendezvous);
        }
        txtfLibelle.clear();
    
    }

    @FXML
    private void handleUpdateRv(ActionEvent event) {
        if(txtfLibelle.getText().trim().isEmpty()){
            Alert alert =new Alert(Alert.AlertType.ERROR);
            alert.setTitle("classe");
            alert.setContentText("Veuillez saisir le libelle");
            alert.show();
        }else{
            listezrendezvousSelected.setLibelle(txtfLibelle.getText());
            if(service.updateListezRendezvous  ( listezrendezvousSelected)){
                Alert alert =new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("classe");
                alert.setContentText("Classe mise a jour avec succes");
                alert.show();
                //Synchrone
                //loadTableView();

             //   obvRendezvous.set(showAllRendez_vous( listezrendezvousSelected), listezrendezvousSelected);
            }
              
        }
        txtfLibelle.clear();
    }

    @FXML
    private void handleDeleteRv(ActionEvent event) {
    }

    @FXML
    private void handleSelectClasse(MouseEvent event) {
    }

}
