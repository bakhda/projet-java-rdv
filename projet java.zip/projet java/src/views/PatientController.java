/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

import entities.User;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import services.Service;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class PatientController implements Initializable {
  private User user;
    private final Service service = new Service();
    private static ConnexionController ctrl;
      public static ConnexionController getCtrl(){
        return ctrl;
    }
    @FXML
    private Button btndmrv;
    @FXML
    private Button btnlister_rv;
    
    
    public User getUser(){
        return user;
    }
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void handledmrv(ActionEvent event) {
                  this.btndmrv.getScene().getWindow().hide();

           AnchorPane root = null;
              
              try {
                  root = FXMLLoader.load(getClass().getResource("/views/v_rendez_vous.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
    }

   

    @FXML
    private void handleListerRv(ActionEvent event) {
        AnchorPane root = null;
                        this.btndmrv.getScene().getWindow().hide();

              try {
                  root = FXMLLoader.load(getClass().getResource("/views/v_ListezRendezvous.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
    }

   
    

    
}
