/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package views;

//import entities.Prestationpatient;
import entities.Prestationpatient;
import entities.Rendez_vous;
import entities.User;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import services.Service;

/**
 * FXML Controller class
 *
 * @author Lenovo
 */
public class PrestationpatientController implements Initializable {
    
    @FXML
    private Text txtError;
    @FXML
    private TextField txtnom;
    @FXML
    private TextField txtprenom;
    
     private User user;
    private final Service service = new Service();
    private static PrestationpatientController ctrl;
    
    private Rendez_vous Rendez_vous;
    @FXML
    private ComboBox<String> handletypecons;
      private void loadComboBoxTypeRdv(ComboBox<String> cboTypeRdv){
        cboTypeRdv.getItems().add("Veuillez Choisir");
        cboTypeRdv.getItems().add("radiologie");
        cboTypeRdv.getItems().add("chirurgie");
        cboTypeRdv.getItems().add("neurologie");
        cboTypeRdv.getSelectionModel().selectFirst();
    }
   
    
      public User getUser(){
        return user;
    }
    
     public static PrestationpatientController getCtrl(){
        return ctrl;
    }
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    

    /**
     * Initializes the controller class.
     */
   
    @Override
    public void initialize(URL location, ResourceBundle resources) {
         txtError.setVisible(false);
         ctrl=this;
         loadComboBoxTypeRdv(handletypecons);  
    }

    @FXML
    private void handlevalider(ActionEvent event) {
        String login = txtnom.getText().trim();
        String inf = txtprenom.getText().trim();
        String libelle="Prestation";
        String typePrestation= handletypecons.getSelectionModel().getSelectedItem();
        
        if(login.isEmpty() || inf.isEmpty())
        {
          txtError.setText("le nom ou le prenom est Obligatoire");
          txtError.setVisible(true);
        }
        else{
               
              //insertion des éléments
              Prestationpatient presp=new Prestationpatient();
              presp.setNom(login);
              presp.setPrenom(inf);
              presp.setLibelle(libelle);
              presp.setPrestation_demander(typePrestation);
              service.addPrestationpatient(presp);
        
        
              //Cache la fénétre de connexion
              this.txtError.getScene().getWindow().hide();
              AnchorPane root = null;
              String role = ConnexionController.getCtrl().getUser().getRole();
              System.out.print(role);
              
              try {
                
                  root = FXMLLoader.load(getClass().getResource("/views/v_patient.fxml"));
                  Scene scene = new Scene(root);
                  Stage stage = new Stage();
                  stage.setScene(scene);
                  stage.show();
                  //popup
                  JOptionPane.showMessageDialog(null,"INSCRIPTION SUCCESSFULL");
                  
                  
                  
              } catch (IOException ex) {
                  Logger.getLogger(ConnexionController.class.getName()).log(Level.SEVERE, null, ex);
              }
                            this.txtError.getScene().getWindow().hide();

          
        }
        
    }

    @FXML
    private void handleclear(ActionEvent event) {
         txtnom.clear();
        txtprenom.clear();
        txtError.setVisible(true);
    }
     

}
